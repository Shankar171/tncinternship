package com.internship.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import com.internship.dao.ApplicantDAO;
import com.internship.dto.Applicant;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/apply")
@MultipartConfig
public class ApplyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Adjust this path to where you want to store the uploaded files
    private static final String UPLOAD_DIR = "C:\\Users\\pavan\\OneDrive\\Desktop\\payment receipt";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String courseType = request.getParameter("courseType");
            String courseInterest = request.getParameter("courseInterest");

            Part filePart = request.getPart("receipt");
            String fileName = filePart.getSubmittedFileName();

            // Save file to disk
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) uploadDir.mkdir();

            String filePath = UPLOAD_DIR + File.separator + fileName;
            try (FileOutputStream fos = new FileOutputStream(filePath);
                 InputStream is = filePart.getInputStream()) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }

            // Save to database using DTO and DAO
            Applicant app = new Applicant(fullName, email, phone, courseType, courseInterest, fileName);
            boolean result = new ApplicantDAO().save(app);

            response.sendRedirect("success.jsp");


        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
