package com.internship.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.internship.connector.DBConnector;
import com.internship.dto.Applicant;

public class ApplicantDAO {
	public static boolean save(Applicant applicant) {
        try (Connection conn = DBConnector.getConnection()) {
            String sql = "INSERT INTO applications (full_name, email, phone, course_type, course_interest, receipt_filename) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, applicant.getFullName());
            stmt.setString(2, applicant.getEmail());
            stmt.setString(3, applicant.getPhone());
            stmt.setString(4, applicant.getCourseType());
            stmt.setString(5, applicant.getCourseInterest());
            stmt.setString(6, applicant.getReceiptFilename());

            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
