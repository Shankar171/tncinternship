package com.internship.dto;

public class Applicant {
	private String fullName;
    private String email;
    private String phone;
    private String courseType;
    private String courseInterest;
    private String receiptFilename;
	
	
	public Applicant(String fullName, String email, String phone, String courseType, String courseInterest,
			String receiptFilename) {
		super();
		this.fullName = fullName;
		this.email = email;
		this.phone = phone;
		this.courseType = courseType;
		this.courseInterest = courseInterest;
		this.receiptFilename = receiptFilename;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCourseType() {
		return courseType;
	}
	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}
	public String getCourseInterest() {
		return courseInterest;
	}
	public void setCourseInterest(String courseInterest) {
		this.courseInterest = courseInterest;
	}
	public String getReceiptFilename() {
		return receiptFilename;
	}
	public void setReceiptFilename(String receiptFilename) {
		this.receiptFilename = receiptFilename;
	}
    
    

}
